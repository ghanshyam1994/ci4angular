<?php

namespace App\Controllers;

class Home extends BaseController
{
	public function __construct()
    {
		$this->EmployModel = model('App\Models\EmployModel');
        
    }
    public function index()
    {
        return view('welcome_message');
    }
	public function get_list()
    {		
		$Employs = $this->EmployModel->findAll();		
        return json_encode($Employs); exit;
    }
    public function insert_employ()
    {	
		print_r($_POST);		exit;
        //return json_encode($Employs); 
    }
}
