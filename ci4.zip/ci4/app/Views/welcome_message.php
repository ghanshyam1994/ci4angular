<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>This is angular datasample by GHANSHYAM SAINI</title>
	<meta name="description" content="The small framework with powerful features">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="shortcut icon" type="image/png" href="/favicon.ico"/>
  <script type="text/javascript" src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-1.8.3.min.js"></script>
    <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/angularjs/1.6.9/angular.min.js"></script>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-/bQdsTh/da6pkI1MST/rWKFNjaCP5gBSY4sEBT38Q/9RBh9AH40zEOg7Hlq2THRZ" crossorigin="anonymous"></script>
	
	
</head>
<body>

<!-- HEADER: MENU + HEROE SECTION -->
<header>


</header>

<!-- CONTENT -->

<section>

	<h1>All sample employs data</h1>
	<button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addnewemploy">
	  Add new employ
	</button>
	<div ng-app="myApp" ng-controller="customersCtrl"> 
	
		<table class="table table-dark table-striped">
		<tr>
		
			<td>ID</td>
			<td>Name</td>
			<td>Email</td>
			<td>Salary</td>
			<td>Date of join</td>			
			<td>Dob</td>
			<td>Action</td>
			
		  </tr>
		  <tr ng-repeat="employ in employs">
		 
			<td>{{ employ.id }}</td>
			<td>{{ employ.Name }}</td>
			<td>{{ employ.email }}</td>
			<td>{{ employ.salary }}</td>
			<td>{{ employ.date_of_join }}</td>
			<td>{{ employ.dob }}</td>
			<td>
				<button type="button" data-id="{{ employ.id }}" ng-click="select(employ)" class="btn btn-info">View</button>
				<button type="button" data-id="{{ employ.id }}" class="btn btn-success">Edit</button>
				<button type="button" data-id="{{ employ.id }}" class="btn btn-danger">Delete</button>
			</td>
			
		  </tr>
		</table>











	
		<div class="modal fade" id="addnewemploy" tabindex="-1" aria-labelledby="addnewemployModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="addnewemployModalLabel">Modal title</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">		
		<form class="row g-3" ng-submit="submitForm()">			
			<div class="col-auto">
				<label for="inputPassword2" class="visually-hidden">Name</label>
				<input type="text" class="form-control" id="Name" ng-model="employ.Name" placeholder="Name">
			</div>
			<div class="col-auto">
				<label for="inputPassword2" class="visually-hidden">Email</label>
				<input type="text" class="form-control" id="Email" ng-model="employ.Email" placeholder="Email">
			</div>
			<div class="col-auto">
				<label for="inputPassword2" class="visually-hidden">Salary</label>
				<input type="number" class="form-control" id="Salary" ng-model="employ.Salary" placeholder="Salary">
			</div>
			<div class="col-auto">
				<label for="inputPassword2" class="visually-hidden">Date of join</label>
				<input type="date" class="form-control" id="d_o_j" ng-model="employ.d_o_j" placeholder="Date of join">
			</div>
			<div class="col-auto">
				<label for="inputPassword2" class="visually-hidden">D.O.B.</label>
				<input type="date" class="form-control" id="dob" ng-model="employ.dob" placeholder="D.O.B.">
			</div>
			<div class="col-auto">
			<button type="reset" class="btn btn-primary mb-3" ng-click="resetForm()" value="Reset" >Reset</button>
				<button type="submit" class="btn btn-primary mb-3">Save Detais</button>
			</div>
		</form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>      
      </div>
    </div>
  </div>
</div>
</div>

<div class="modal fade" id="employdetails" tabindex="-1" aria-labelledby="employdetailsModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="employdetailsModalLabel">Modal title</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
	  
	 
		 <span ng-show="selectedItem">{{selectedItem}}</span>
        <div>ID</div>
			<div>Name </div>
			<div>Email</div>
			<div>Salary</div>
			<div>Date of join</td>			
			<div>Dob</div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>        
      </div>
    </div>
  </div>
</div>

</div>










	</div>

</section>

<div class="further">

	<section>




	</section>

</div>

<!-- FOOTER: DEBUG INFO + COPYRIGHTS -->

<footer>
	
</footer>

<script>
	var app = angular.module('myApp', []);
	app.controller('customersCtrl', function($scope, $http) {
		$http.get("/ci4/public/home/get_list")
		.then(function (response) {$scope.employs = response.data;});
		$scope.select = function(item) {
			var dlgElem = angular.element("#employdetails");
			if (dlgElem) {
			  	$scope.selectedItem = item;
			   //dlgElem.scope().selectedItem = item;
			   dlgElem.modal("show");
			}
			//
		};
		//$scope.employ = angular.copy($scope.originalemploy);
		$scope.submitForm = function () {				
		var onSuccess = function (data, status, headers, config) {
			alert('Student saved successfully.');
		};

		var onError = function (data, status, headers, config) {
			alert('Error occured.');
		}

		$http.post('/ci4/public/home/insert_employ', { employ:$scope.employ }).then(function(result) {
			onSuccess;
		}, function(error) {
			onError;
		});  
		/*$http({
			method: "POST",
			url: "/ci4/public/home/insert_employ",
			dataType: 'json',
			data: { employ:$scope.employ },
			headers: { "Content-Type": "application/json" }
		}).then(function(result) {
			
		}, function(error) {
		//Error
		});  */

		};

		
		//6. create resetForm() function. This will be called on Reset button click.  
		$scope.resetForm = function () {
			$scope.student = angular.copy($scope.OriginalStudent);
		};
	});
</script>

</body>
</html>
